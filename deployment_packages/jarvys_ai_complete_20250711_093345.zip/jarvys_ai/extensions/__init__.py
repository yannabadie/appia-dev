"""
Extensions JARVYS_AI - Modules spécialisés pour fonctionnalités avancées
"""

__version__ = "1.0.0"
